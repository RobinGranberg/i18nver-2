package i18nPackage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class I18nApplicationTests {

	@Test
	void contextLoads() {
	}

}
